name = 'primal-grakn'
from primal_grakn.primal_grakn import *
